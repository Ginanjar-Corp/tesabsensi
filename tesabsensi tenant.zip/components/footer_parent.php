<?php
// project-root/components/footer_parent.php
?>
        <footer class="bg-gray-800 text-white p-4 text-center mt-8 main-footer">
            <p>&copy; <?php echo date('Y'); ?> <?php echo APP_NAME; ?>. Hak Cipta Dilindungi.</p>
        </footer>
    </div> <!-- Tutup main-content-wrapper -->
</body>
</html>
