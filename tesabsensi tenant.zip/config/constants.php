<?php
// project-root/config/constants.php
define('DB_HOST', 'localhost');
define('DB_NAME', 'u7653190_tesabsensi');
define('DB_USER', 'u7653190_tesabsensi');
define('DB_PASS', 'tesabsensi'); // Sesuaikan dengan password database Anda
define('DB_CHARSET', 'utf8mb4');
define('DB_COLLATE', 'utf8mb4_unicode_ci');